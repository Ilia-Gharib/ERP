from django.shortcuts import render, redirect , get_object_or_404
from django.http import JsonResponse
from .forms import ProductForm
from .models import Product , Warehouse, Invoice , InvoiceItem , Customer , SiteSetting , Category 
from .forms import InvoiceForm, InvoiceItemFormSet , SiteSettingForm , CategoryForm , WarehouseForm
from django.db.models import Max
from datetime import datetime

def user_logo_setting(request):
    setting = SiteSetting.objects.first()

    if request.method == 'POST':
        form = SiteSettingForm(request.POST, request.FILES, instance=setting)
        if form.is_valid():
            form.save()
            return redirect('logo_settings')
    else:
        form = SiteSettingForm(instance=setting)

    return render(request, 'logo_setting.html', {
        'form': form,
        'setting': setting
    })

def hesabdari_settings(request):
    return render(request, 'hesabdari_settings.html')

def hesabdari_view(request):
    return render(request, 'hesabdari.html')

def product_create_view(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('product-list')  # بعد از ثبت به لیست برگرد
    else:
        form = ProductForm()
    return render(request, 'product_form.html', {'form': form})

def product_list_view(request):
    products = Product.objects.all()
    return render(request, 'product_list.html', {'products': products})

def inventory_list_view(request):
    Warehouses = Warehouse.objects.all()
    return render(request, 'inventory_list.html', {'Warehouses': Warehouses})


# inventory add 

def warehouse_create(request):
    if request.method == 'POST':
        form = WarehouseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory_list')
    else:
        form = WarehouseForm()
    return render(request, 'inventory_add.html', {'form': form})

# صورت حساب ها
def invoice_list(request):
    invoices = Invoice.objects.all().order_by('-date')
    return render(request, 'invoice.html', {'invoices': invoices})


def create_invoice(request):
    products = Product.objects.all()
    customers = Customer.objects.all()

    next_invoice_number = str((Invoice.objects.aggregate(Max('id'))['id__max'] or 0) + 1)


    if request.method == 'POST':
        form = InvoiceForm(request.POST)
        formset = InvoiceItemFormSet(request.POST)

        # گرفتن مقدار ورودی مشتری
        customer_name_input = request.POST.get('customer_name_input', '').strip()
        customer_id = request.POST.get('customer')

        if customer_name_input:
            customer, _ = Customer.objects.get_or_create(name=customer_name_input)
        elif customer_id:
            customer = get_object_or_404(Customer, pk=customer_id)
        else:
            form.add_error(None, 'لطفاً مشتری را انتخاب کرده یا یک مشتری جدید وارد کنید.')
            formset = InvoiceItemFormSet()
            return render(request, 'create_invoice.html', {
                'form': form,
                'formset': formset,
                'invoice_number': '---',
                'product_list': products,
                'customers': customers,
            })

        if form.is_valid() and formset.is_valid():
            invoice = form.save(commit=False)
            invoice.customer = customer
            invoice.save()

            for item_form in formset:
                cd = item_form.cleaned_data
                if not cd:
                    continue  # فرم خالی رو رد کنه

                product_name_input = cd.get('product_name_input', '').strip()
                product = cd.get('product')

                if product_name_input:
                    product, _ = Product.objects.get_or_create(
                        name=product_name_input,
                        defaults={
                            'sku': f'SKU-{product_name_input[:10]}',
                            'category': None,
                            'unit': 'عدد',
                            'purchase_price': 0,
                            'selling_price': 0,
                            'stock': 0,
                            'warehouse': None,
                        }
                    )
                elif product:
                    pass  # از محصول انتخاب شده استفاده شود
                else:
                    continue  # نه محصولی انتخاب شده و نه چیزی نوشته شده

                InvoiceItem.objects.create(
                    invoice=invoice,
                    product=product,
                    quantity=cd['quantity'],
                    unit_price=cd['unit_price'],
                )

            return redirect('invoice_detail', pk=invoice.pk)

    else:
        form = InvoiceForm()
        formset = InvoiceItemFormSet()
        next_invoice_number = str((Invoice.objects.aggregate(Max('id'))['id__max'] or 0) + 1)

    return render(request, 'create_invoice.html', {
        'form': form,
        'formset': formset,
        'invoice_number': next_invoice_number,
        'product_list': products,
        'customers': customers,
    })


def invoice_detail(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    items = InvoiceItem.objects.filter(invoice=invoice)
    return render(request, 'invoice_detail.html', {
        'invoice': invoice,
        'items': items
    })


# category add + list

def category_create(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_list')  # یا هرجایی که می‌خوای بعد از ثبت بره
    else:
        form = CategoryForm()
    return render(request, 'category_add.html', {'form': form})

def category_list(request):
    categories = Category.objects.all()
    return render(request, 'category_list.html', {'categories': categories})



#پرینت فاکتور
def invoice_print(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    settings = SiteSetting.objects.last()  # فرض می‌کنیم یک رکورد داریم
    #    return render(request, 'invoice_print2.html', {
    return render(request, 'invoice_print.html', {
        'invoice': invoice,
        'logo': settings.logo.url if settings and settings.logo else None
    })


