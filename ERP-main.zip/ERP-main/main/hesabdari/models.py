from django.db import models
from django.utils import timezone

class SiteSetting(models.Model):
    logo = models.ImageField(upload_to='logos/', default='logos/default_logo.png')
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "تنظیمات سایت"

    class Meta:
        verbose_name = "تنظیمات"
        verbose_name_plural = "تنظیمات"




class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="نام دسته‌بندی")

    def __str__(self):
        return self.name

class Warehouse(models.Model):
    name = models.CharField(max_length=100, verbose_name="نام انبار")
    location = models.CharField(max_length=255, blank=True, null=True, verbose_name="موقعیت")
    # آدرس‌دهی داخلی (اختیاری)
    floor = models.CharField(max_length=50, blank=True, null=True, verbose_name="طبقه")
    section = models.CharField(max_length=50, blank=True, null=True, verbose_name="بخش")
    block = models.CharField(max_length=50, blank=True, null=True, verbose_name="بلوک") 
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=200, verbose_name="نام محصول")
    sku = models.CharField(max_length=50, unique=True, verbose_name="کد کالا / بارکد")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, verbose_name="دسته‌بندی")
    unit = models.CharField(max_length=20, verbose_name="واحد", help_text="مثل: عدد، کیلو، لیتر")
    purchase_price = models.DecimalField(max_digits=12, decimal_places=2, verbose_name="قیمت خرید (با مالیات)")
    selling_price = models.DecimalField(max_digits=12, decimal_places=2, verbose_name="قیمت فروش (با مالیات)")
    stock = models.PositiveIntegerField(default=0, verbose_name="موجودی")
    warehouse = models.ForeignKey(Warehouse, on_delete=models.SET_NULL, null=True, verbose_name="انبار")
    description = models.TextField(blank=True, null=True, verbose_name="توضیحات")

    def __str__(self):
        return self.name




# فاکتور 

class Customer(models.Model):
    name = models.CharField(max_length=255, verbose_name="نام مشتری")
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name="شماره تماس")
    address = models.TextField(blank=True, null=True, verbose_name="آدرس")

    def __str__(self):
        return self.name

class Invoice(models.Model):
    number = models.CharField(max_length=50, verbose_name="شماره فاکتور", unique=True)
    date = models.DateField(default=timezone.now, verbose_name="تاریخ")
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name="مشتری")
    discount_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="درصد تخفیف")
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=9, verbose_name="درصد مالیات")
    notes = models.TextField(blank=True, null=True, verbose_name="یادداشت‌ها")

    def save(self, *args, **kwargs):
        if not self.pk and not self.number:
            last_invoice = Invoice.objects.order_by('-id').first()
            if last_invoice and last_invoice.number.isdigit():
                self.number = str(int(last_invoice.number) + 1)
            else:
                self.number = "1"
        super().save(*args, **kwargs)


    def __str__(self):
        return f"فاکتور {self.number}"

    @property
    def total_amount(self):
        return sum(item.total_price for item in self.items.all())

    @property
    def tax_amount(self):
        return self.total_amount * self.tax_percent / 100

    @property
    def discount_amount(self):
        return self.total_amount * self.discount_percent / 100

    @property
    def final_amount(self):
        return self.total_amount + self.tax_amount - self.discount_amount


class InvoiceItem(models.Model):
    invoice = models.ForeignKey(Invoice, related_name='items', on_delete=models.CASCADE, verbose_name="فاکتور")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="محصول")
    quantity = models.PositiveIntegerField(verbose_name="تعداد")
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, verbose_name="قیمت واحد")

    @property
    def total_price(self):
        return self.unit_price * self.quantity

    def __str__(self):
        return f"{self.product.name} - {self.quantity}"
