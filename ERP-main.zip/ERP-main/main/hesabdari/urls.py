from django.urls import path
from . import views
from .views import hesabdari_view , create_invoice , invoice_list , invoice_print , user_logo_setting , hesabdari_settings
 

urlpatterns = [
    path('', hesabdari_view, name='hesabdari'),
    path('products/add/', views.product_create_view, name='product-add'),
    path('products/', views.product_list_view, name='product-list'),
    path('inventory/', views.inventory_list_view , name = 'inventory_list'),
    path('inventory/add/', views.warehouse_create, name='inventory_add'),
    path('invoices/add/', create_invoice, name='create_invoice'),
    path('invoices/', invoice_list , name = "invoice_list"),
    path('invoices/<int:pk>/', views.invoice_detail, name='invoice_detail'),
    path('invoice/<int:pk>/print/', views.invoice_print, name='invoice_print'),
    path('settings/logo', views.user_logo_setting, name='logo_settings'),
    path('settings/', views.hesabdari_settings, name='hesabdari_settings'),
    path('categories/', views.category_list, name='category_list'),
    path('categories/add/', views.category_create, name='category_add'),

]
