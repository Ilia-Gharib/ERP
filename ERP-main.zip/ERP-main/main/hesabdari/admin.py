from django.contrib import admin
from .models import Product, Category, Warehouse, Invoice, InvoiceItem, Customer , SiteSetting

admin.site.register(SiteSetting)



# دسته‌بندی
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']

# انبار
@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ['name', 'location', 'floor', 'section', 'block']

# محصول
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'sku', 'purchase_price', 'selling_price', 'stock', 'warehouse']
    search_fields = ['name', 'sku']
    list_filter = ['category', 'warehouse']

# مشتری
@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['name', 'phone', 'address']
    search_fields = ['name', 'phone']

# آیتم‌های فاکتور به صورت اینلاین در فاکتور
class InvoiceItemInline(admin.TabularInline):
    model = InvoiceItem
    extra = 1  # تعداد فرم‌های خالی پیش‌فرض برای آیتم‌ها

# فاکتور
@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ['number', 'date', 'customer', 'total_amount', 'tax_amount', 'discount_amount', 'final_amount']
    inlines = [InvoiceItemInline]
    readonly_fields = ['number']
    list_filter = ['date', 'customer']
    search_fields = ['number', 'customer__name']
