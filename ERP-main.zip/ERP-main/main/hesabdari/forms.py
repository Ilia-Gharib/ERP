from django import forms
from .models import Product, Invoice, InvoiceItem , SiteSetting , Category, Warehouse
from django.forms import inlineformset_factory

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            'name', 'sku', 'category', 'unit', 'purchase_price',
            'selling_price', 'stock', 'warehouse', 'description'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
class InvoiceForm(forms.ModelForm):
    customer_name_input = forms.CharField(
        label="نام مشتری جدید",
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'نام مشتری جدید'})
    )

    class Meta:
        model = Invoice
        fields = ['date', 'customer', 'discount_percent', 'tax_percent', 'notes']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }

class InvoiceItemForm(forms.ModelForm):
    product_name_input = forms.CharField(
        label="نام محصول جدید",
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'نام محصول جدید'})
    )

    class Meta:
        model = InvoiceItem
        fields = ['product', 'quantity', 'unit_price']

InvoiceItemFormSet = inlineformset_factory(
    Invoice,
    InvoiceItem,
    form=InvoiceItemForm,  # ← فرم سفارشی استفاده شود
    extra=1,
    can_delete=True
)



class SiteSettingForm(forms.ModelForm):
    class Meta:
        model = SiteSetting
        fields = ['logo']



class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name']

class WarehouseForm(forms.ModelForm):
    class Meta:
        model = Warehouse
        fields = ['name', 'location', 'floor', 'section', 'block']