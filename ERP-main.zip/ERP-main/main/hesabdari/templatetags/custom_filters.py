from django import template
from persiantools.jdatetime import JalaliDate
from num2words import num2words

register = template.Library()

@register.filter
def to_jalali(value):
    """تبدیل تاریخ میلادی به شمسی"""
    try:
        return JalaliDate(value).strftime('%Y/%m/%d')
    except:
        return value

@register.filter
def num2words_fa(value):
    """تبدیل عدد به حروف فارسی"""
    try:
        return num2words(value, lang='fa')
    except:
        return value
