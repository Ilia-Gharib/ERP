from django.contrib import admin
from django.urls import path
from django.urls import include
from django.urls import re_path
from django.shortcuts import redirect
from account.views import CreateUserView
from rest_framework_simplejwt.views import TokenObtainPairView , TokenRefreshView
from django.conf import settings
from django.conf.urls.static import static

def redirect_to_dashboard(request):
    return redirect('/dashboard/')

urlpatterns = [
    path('', redirect_to_dashboard),  # Redirect the root URL to /dashboard
    path('admin/', admin.site.urls),
    path('account/' , include('account.urls')),
    path('dashboard/', include('dashboard.urls')),
    path("account/", include("rest_framework.urls")),
    path("account/user/register/", CreateUserView.as_view(), name="register"),
    path("account/token/", TokenObtainPairView.as_view(), name="get_token"),
    path("account/token/refresh/", TokenRefreshView.as_view(), name="refresh"),
    path("hesabdari/", include('hesabdari.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
