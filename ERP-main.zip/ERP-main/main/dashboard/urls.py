from django.urls import path
from .views import dashboard_view , CheckAuthView
from .views import get_user_info


urlpatterns = [
    path('', dashboard_view, name='dashboard'),  # maps to /dashboard/
    path('check-auth/', CheckAuthView.as_view()),
    path('get-user/', get_user_info, name='get_user'),
]
