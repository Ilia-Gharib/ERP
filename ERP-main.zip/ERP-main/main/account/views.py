from django.shortcuts import render , redirect
import requests
from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated , AllowAny
from .serializers import UserSerializer
from django.conf import settings

class CreateUserView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [AllowAny]

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        response = requests.post(
            request.build_absolute_uri('/account/token/'),
            data={'username': username, 'password': password}
        )
        if response.status_code == 200:
            tokens = response.json()
            response = redirect('dashboard')
            response.set_cookie('access_token', tokens['access'], httponly=True)
            return response
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')


def logout_view(request):
    response = redirect('login')
    response.delete_cookie('access_token')
    return response
